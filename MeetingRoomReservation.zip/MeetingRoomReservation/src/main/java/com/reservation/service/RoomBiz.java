package com.reservation.service;

import com.reservation.domain.Room;

import java.util.List;

public interface RoomBiz {
    List<Room> getAllRoomList();
}
